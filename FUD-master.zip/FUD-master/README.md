# FUD
Bypass Window 10 Defender Firewall & Bypass UAC 
# How to use 
1. git clone https://github.com/Ignitetch/FUD.git
2. cd FUD
3. ./FUD.sh
# Intructions
1. Use Carefully with Patience 
2. For Bypass All Security This Tool Make 3 Payloads Instantly
3. Donot Need Send Payload on victim They Provide Link To Send The Victim
